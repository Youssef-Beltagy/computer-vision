#include "Transformations.h"
#include <cmath> 

using namespace std;

pixel Transformations::interpolate(const Image& input, double row, double col)
{

	if (row < 0 || col < 0) return pixel();

	size_t up = floor(row);
	size_t down = ceil(row);
	size_t left = floor(col);
	size_t right = ceil(col);

	if (down >= input.getRows() || right >= input.getCols()) return pixel();

	// by now all four pixels should be in the input imager or 2 or 3 of them are dublicates

	double rowa = row - up;
	double cola = col - left;

	pixel ul = input.getPixel(up, left);
	pixel ll = input.getPixel(down, left);
	pixel ur = input.getPixel(up, right);
	pixel lr = input.getPixel(down, right);

	byte red, green, blue;

	red = ul.red * (1 - rowa) * (1 - cola)
		+ ll.red * rowa * (1 - cola) // check these calculations again to be sure---------------------
		+ ur.red * (1 - rowa) * cola
		+ lr.red * rowa * cola;

	green = ul.green * (1 - rowa) * (1 - cola)
		+ ll.green * rowa * (1 - cola) // check these calculations again to be sure---------------------
		+ ur.green * (1 - rowa) * cola
		+ lr.green * rowa * cola;

	blue = ul.blue * (1 - rowa) * (1 - cola)
		+ ll.blue * rowa * (1 - cola) // check these calculations again to be sure---------------------
		+ ur.blue * (1 - rowa) * cola
		+ lr.blue * rowa * cola;


	// return
	pixel ans;

	ans.red = red;
	ans.green = green;
	ans.blue = blue;

	return ans;
}

Image Transformations::transform(const Image& input, double colS, double rowS, double colT, double rowT, double theta, double shear)
{

	double center[2] = { input.getCols() / 2, input.getRows() / 2 };

	double translation[2] = { colT, rowT };

	double weights[2][2];


	{

		theta = theta * Transformations::PI / 180;

		weights[0][0] = rowS * cos(theta) / ( rowS * colS );
		weights[0][1] = colS * ( -shear * cos(theta) + sin(theta) ) / (rowS * colS);

		weights[1][0] = -rowS * sin(theta) / (rowS * colS);
		weights[1][1] = colS * ( shear * sin(theta) + cos(theta) ) / (rowS * colS);

	}

	Image output(input.getRows(), input.getCols());


	double coordinates[2];

	double temp[2];

	for (size_t i = 0; i < output.getRows(); i++) {
		for (size_t j = 0; j < output.getCols(); j++) {

			temp[0] = j - translation[0] - center[0];
			temp[1] = i - translation[1] - center[1];

			coordinates[0] = weights[0][0] * temp[0] + weights[0][1] * temp[1] + center[0];
			coordinates[1] = weights[1][0] * temp[0] + weights[1][1] * temp[1] + center[1];

			pixel tempPixel = interpolate(input, coordinates[1], coordinates[0]);

			output.setPixel(i, j, tempPixel);

		}
	}


	return output;
}

void Transformations::setImageColor(Image& image, byte red, byte green, byte blue)
{
	for (size_t i = 0; i < image.getRows(); i++) {
		for (size_t j = 0; j < image.getCols(); j++) {

			image.setPixel(i, j, red, green, blue);

		}

	}
}
