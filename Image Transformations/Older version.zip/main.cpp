// Simple program to use the CSS 487 Image class to create a photonegative and rotation of "test.gif"
// Author: Clark Olson

#include "Image.h"
#include "Transformations.h"
#include <iostream> //--------------------------------------------------------------


// rotate
// Preconditions:  input image passed in is correctly allocated/formated
// Postconditions: returns a new image that is the input rotate 90 degrees CCW
Image rotate(const Image& input) {
	Image output(input.getCols(), input.getRows());

	// Loop over all pixels and copy them into output image.
	// The output is a 90 degree rotation of the input image (counterclockwise)
	for (int row = 0; row < input.getRows(); row++) {
		for (int col = 0; col < input.getCols(); col++) {
			output.setPixel(output.getRows() - col - 1, row, input.getPixel(row, col));
		}
	}

	return output;
}

//testing function
void test() {

	{
		size_t row = 2;
		size_t col = 3;

		Image input(row, col);

		//input.setPixel(1,1, 0, 255, 0);

		Transformations::setImageColor(input, 255, 255, 255);

		Image output(row * 100, col * 100);

		pixel temp = Transformations::interpolate(input, 1.5, 1);

		Transformations::setImageColor(output, temp.red, temp.green, temp.blue);

		output.writeImage("Testing1.gif");

	}

}


// main method
// Preconditions:  test1.gif exists and is a correctly formatted GIF image
// Postconditions: Creates an image output.gif that is the rotation and photonegative of test.gif
int main(int argc, char* argv[]) {

	if (argc != 7) {
		cout << "This program only works with six arguments." <<
			 " Please re-run with six arguments other than the prognam name." << endl;
		return -1;
	}

	double colS; // scale of the cols
	double rowS; // scale of the rows
	double colT; // translation of the cols
	double rowT; // translation of the rows
	double theta;// rotation angle in degrees
	double shear;// shear factor

	// read the values from the function arguments.
	sscanf_s(argv[1], "%lf", &colS);
	sscanf_s(argv[2], "%lf", &rowS);
	sscanf_s(argv[3], "%lf", &colT);
	sscanf_s(argv[4], "%lf", &rowT);
	sscanf_s(argv[5], "%lf", &theta);
	sscanf_s(argv[6], "%lf", &shear);


	Image input("test1.gif");// read input

	// Call the transform function to make a new image with the specified transformations.
	Image output = Transformations::transform(input, colS, rowS, colT, rowT, theta, shear);

	// Write a gif file for the output image.
	output.writeImage("output.gif");

	return 0;

}