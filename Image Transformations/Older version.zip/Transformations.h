#ifndef TRANSFORMATIONS_H
#define TRANSFORMATIONS_H

#include "Image.h"
#include <math.h>

namespace Transformations {

	const double PI = 3.141592653589;

	// pos input
	// returns a pixel that is the bilinear interpolation of its surrounding four
	pixel interpolate(const Image& input, double row, double col);

	Image transform(const Image& input, double colS, double rowS, double colT, double rowT, double theta, double shear);

	void setImageColor(Image& image, byte red, byte green, byte blue);

};

#endif